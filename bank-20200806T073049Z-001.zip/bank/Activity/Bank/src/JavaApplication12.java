public class JavaApplication12 {

}
